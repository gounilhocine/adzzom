package io.adzoom.service;

import java.util.List;

import org.jvnet.hk2.annotations.Service;

@Service
public abstract class BaseService<T> {

	private T t;

	abstract void dalete(T t);
	
	abstract int daleteById(Long id);

	public T get() {
		return this.t;
	}

	abstract List<T> getAllObject();

	abstract T getObjectById(Long id);
	
	abstract T saveOrUpdate(T t);

}
