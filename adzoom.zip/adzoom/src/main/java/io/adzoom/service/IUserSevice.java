package io.adzoom.service;

import javax.servlet.http.HttpServletRequest;

import org.jvnet.hk2.annotations.Service;
import org.springframework.security.core.userdetails.UserDetailsService;

import io.adzoom.datasource.entity.User;
import io.adzoom.model.UserModel;

@Service
public interface IUserSevice extends UserDetailsService {
	User findByEmail(String email);
	User save(UserModel registrationModel, HttpServletRequest req);
}
