package io.adzoom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import io.adzoom.datasource.entity.Ad;
import io.adzoom.datasource.repo.AdRepository;

public class AdService extends BaseService<Ad> {

	@Autowired
	AdRepository adRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	void dalete(Ad t) {
		adRepository.delete(t);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	int daleteById(Long id) {
		return adRepository.deleteAdById(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	List<Ad> getAllObject() {
		return (List<Ad>) adRepository.findAll();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	Ad getObjectById(Long id) {
		return adRepository.findAdById(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	Ad saveOrUpdate(Ad t) {
		return adRepository.save(t);
	}

}
