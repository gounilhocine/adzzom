package io.adzoom.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.adzoom.datasource.entity.Category;
import io.adzoom.datasource.entity.City;
import io.adzoom.datasource.entity.Country;
import io.adzoom.datasource.entity.Enumeration;
import io.adzoom.datasource.entity.Language;
import io.adzoom.datasource.entity.SubCategory;
import io.adzoom.datasource.repo.CategoryRepository;
import io.adzoom.datasource.repo.CityRepository;
import io.adzoom.datasource.repo.CountryRepository;
import io.adzoom.datasource.repo.EnumerationRepository;
import io.adzoom.datasource.repo.LanguageRepository;
import io.adzoom.datasource.repo.SubCategoryRepository;
import io.adzoom.model.CodeLabel;

@Service
public class MasterDataService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private SubCategoryRepository subCategoryRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private LanguageRepository languageRepository;
	
	@Autowired
	private EnumerationRepository enumerationRepository;

	private String label = null;

	private List<CodeLabel> codeLabels = new ArrayList<CodeLabel>();

	private CodeLabel codeLabel = new CodeLabel();

	public Category getCategoryById(Long id) { Category category = categoryRepository.findCategoryById(id); return category; }

	public CodeLabel getCategoryCodeLabelByLanguage(Long id, String language) {
		Category category = categoryRepository.findCategoryById(id);
		if (category != null) {
			category.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					codeLabel.setCode(String.valueOf(item.getId()));
					codeLabel.setCode(String.valueOf(item.getLabel()));
				}
			});
		}
		return codeLabel;
	}

	public List<CodeLabel> getCategoryCodeLabelListByIdAndLanguage(String language) {
		List<Category> categories = (List<Category>) categoryRepository.findAll();
		if (categories != null) {
			categories.forEach(item -> {
				item.getName().getTranslations().forEach(iitem -> {
					if (StringUtils.equalsIgnoreCase(iitem.getLanguage().getCode(), language)) {
						CodeLabel codeLabel = new CodeLabel();
						codeLabel.setCode(String.valueOf(item.getId()));
						codeLabel.setCode(String.valueOf(iitem.getLabel()));
						codeLabels.add(codeLabel);
					}
				});
			});
		}
		return codeLabels;
	}

	public String getCategoryNameByIdAndByLanguage(Long id, String language) {
		Category category = categoryRepository.findCategoryById(id);
		if (category != null && category.getName() != null && category.getName().getTranslations() != null) {
			category.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					label = item.getLabel();
				}
			});
		}
		return label;
	}

	public Country getCountryById(Long id) { Country country = countryRepository.findCountryById(id); return country; }

	public CodeLabel getCountryCodeLabelByLanguage(Long id, String language) {
		Country country = countryRepository.findCountryById(id);
		if (country != null) {
			country.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					codeLabel.setCode(String.valueOf(item.getId()));
					codeLabel.setCode(String.valueOf(item.getLabel()));
				}
			});
		}
		return codeLabel;
	}

	public List<CodeLabel> getCountryCodeLabelListByIdAndLanguage(String language) {
		List<Country> countries = (List<Country>) countryRepository.findAll();
		if (countries != null) {
			countries.forEach(item -> {
				item.getName().getTranslations().forEach(iitem -> {
					if (StringUtils.equalsIgnoreCase(iitem.getLanguage().getCode(), language)) {
						CodeLabel codeLabel = new CodeLabel();
						codeLabel.setCode(String.valueOf(item.getId()));
						codeLabel.setCode(String.valueOf(iitem.getLabel()));
						codeLabels.add(codeLabel);
					}
				});
			});
		}
		return codeLabels;
	}

	public String getCountryNameByIdAndByLanguage(Long id, String language) {
		Country country = countryRepository.findCountryById(id);
		if (country != null && country.getName() != null && country.getName().getTranslations() != null) {
			country.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					label = item.getLabel();
				}
			});
		}
		return label;
	}

	public Language getLanguageByCode(String languageCode) { Language langauge = languageRepository.findLanguageByCode(languageCode); return langauge; }

	public Language getLanguageById(Long id) { Language langauge = languageRepository.findLanguageById(id); return langauge; }

	public CodeLabel getLanguageCodeLabelByLanguage(Long id, String language) {
		Language Language = languageRepository.findLanguageById(id);
		if (Language != null) {
			Language.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					codeLabel.setCode(String.valueOf(item.getId()));
					codeLabel.setCode(String.valueOf(item.getLabel()));
				}
			});
		}
		return codeLabel;
	}

	public Enumeration getLanguageCodeLabelByLanguage(String languageCode) { Language Language = languageRepository.findLanguageByCode(languageCode); return Language.getName(); }

	public List<CodeLabel> getLanguageCodeLabelListByIdAndLanguage(String language) {
		List<Language> labguages = (List<Language>) languageRepository.findAll();
		if (labguages != null) {
			labguages.forEach(item -> {
				item.getName().getTranslations().forEach(iitem -> {
					if (StringUtils.equalsIgnoreCase(iitem.getLanguage().getCode(), language)) {
						CodeLabel codeLabel = new CodeLabel();
						codeLabel.setCode(String.valueOf(item.getId()));
						codeLabel.setCode(String.valueOf(iitem.getLabel()));
						codeLabels.add(codeLabel);
					}
				});
			});
		}
		return codeLabels;
	}

	public String getLanguageNameByIdAndByLanguage(Long id, String language) {
		Language Language = languageRepository.findLanguageById(id);
		if (Language != null && Language.getName() != null && Language.getName().getTranslations() != null) {
			Language.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					label = item.getLabel();
				}
			});
		}
		return label;
	}

	/**
	 * @param id
	 * @return
	 */
	public SubCategory getSubCategoryById(Long id) { SubCategory subCategory = subCategoryRepository.findSubCategoryById(id); return subCategory; }

	/**
	 * @param id
	 * @param language
	 * @return
	 */
	public CodeLabel getSubCategoryCodeLabelByLanguage(Long id, String language) {
		SubCategory subCategory = subCategoryRepository.findSubCategoryById(id);
		if (subCategory != null) {
			subCategory.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					codeLabel.setCode(String.valueOf(item.getId()));
					codeLabel.setCode(String.valueOf(item.getLabel()));
				}
			});
		}
		return codeLabel;
	}

	/**
	 * @param language
	 * @return
	 */
	public List<CodeLabel> getSubCategoryCodeLabelListByIdAndLanguage(String language) {
		List<SubCategory> subCategories = (List<SubCategory>) subCategoryRepository.findAll();
		if (subCategories != null) {
			subCategories.forEach(item -> {
				item.getName().getTranslations().forEach(iitem -> {
					if (StringUtils.equalsIgnoreCase(iitem.getLanguage().getCode(), language)) {
						CodeLabel codeLabel = new CodeLabel();
						codeLabel.setCode(String.valueOf(item.getId()));
						codeLabel.setCode(String.valueOf(iitem.getLabel()));
						codeLabels.add(codeLabel);
					}
				});
			});
		}
		return codeLabels;
	}

	/**
	 * @param id
	 * @param language
	 * @return
	 */
	public String getSubCategoryNameByIdAndByLanguage(Long id, String language) {
		SubCategory subCategory = subCategoryRepository.findSubCategoryById(id);
		if (subCategory != null && subCategory.getName() != null && subCategory.getName().getTranslations() != null) {
			subCategory.getName().getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					label = item.getLabel();
				}
			});
		}
		return label;
	}

	/**
	 * @param countryId
	 * @return
	 */
	public Country getCountryByIdAndByLanguage(Long countryId) { return countryRepository.findCountryById(countryId); }

	/**
	 * @param cityId
	 * @return
	 */
	public City getCityById(String cityId) { return cityRepository.findCityById(cityId); }

	/**
	 * @param id
	 * @param language
	 * @return
	 */
	public String getEnumerationByIdAndByLanguage(Long id, String language) { // TODO Auto-generated method stub
		Enumeration enumeration = enumerationRepository.findEnumerationById(id);
		if (enumeration != null ) {
			enumeration.getTranslations().forEach(item -> {
				if (StringUtils.equalsIgnoreCase(item.getLanguage().getCode(), language)) {
					label = item.getLabel();
				}
			});
		}
		return label;
	}
}
