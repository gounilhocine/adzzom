package io.adzoom.service;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import io.adzoom.datasource.entity.Enumeration;
import io.adzoom.datasource.entity.Language;
import io.adzoom.datasource.entity.Role;
import io.adzoom.datasource.entity.User;
import io.adzoom.datasource.repo.EnumerationRepository;
import io.adzoom.datasource.repo.UserRepositoty;
import io.adzoom.model.UserModel;
import io.adzoom.util.SessionUtils;
import io.adzoom.util.TwiAdsEnum;
import io.adzoom.util.TwiAdsEnum.AccountStatus;

@Service("userService")
public class UserService extends BaseService<User> implements IUserSevice {

	@Autowired
	private UserRepositoty userRepository;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private EnumerationRepository enumerationRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	void dalete(User user) {
		userRepository.delete(user);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	int daleteById(Long id) {
		return userRepository.deleteUserById(id);
	}

	@Override
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	List<User> getAllObject() {
		return (List<User>) userRepository.findAll();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	User getObjectById(Long id) {
		return userRepository.findUserById(id);
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = userRepository.findByEmail(email);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				mapRolesToAuthorities(user.getRoles()));
	}

	private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
		return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
	}

	@Override
	public User save(UserModel model, HttpServletRequest req) {
		User user = new User();
		user.setFirstName(model.getFirstName());
		user.setLastName(model.getLastName());
		user.setPhoto(null);
		user.setLocation(null);
		user.setAds(null);
		user.setInbox(null);
		user.setEmail(model.getEmail());
		user.setPassword(passwordEncoder.encode(model.getPassword()));
		Set<Role> roles = new HashSet<Role>();
		roles.add(new Role(TwiAdsEnum.Role.ROLE_USER.toString()));
		user.setRoles(roles);
		user.setAccountStatus(AccountStatus.TO_VALIDATE);
		Language language = new Language();
		language.setCode(SessionUtils.getLanguage(req));
		language.setCreateDate(new Date());
		Enumeration enumeration = enumerationRepository
				.findByCode("LANGUAGE_" + SessionUtils.getLanguage(req).toString().toUpperCase());
		language.setName(enumeration);
		user.setLanguage(language);
		return userRepository.save(user);
	}
	
	

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	User saveOrUpdate(User user) {
		return userRepository.save(user);
	}

	public void update(@Valid UserModel model, HttpServletRequest request) { 
	 }

	public void update(User user) { // TODO Auto-generated method stub
	 }

}
