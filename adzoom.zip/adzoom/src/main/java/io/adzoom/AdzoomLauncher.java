package io.adzoom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan("io.adzoom")
@EnableJpaRepositories("io.adzoom.datasource.repo")
@EntityScan(basePackages = { "io.adzoom.datasource.entity" })
public class AdzoomLauncher {
	public static void main(String[] args) {
		SpringApplication.run(AdzoomLauncher.class, args);
	}
}
