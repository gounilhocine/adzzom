package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "SubCategory", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class SubCategory extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -7314143890499579582L;

	@JoinColumn(name = "id")
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Enumeration.class, fetch = FetchType.LAZY)
	private Enumeration name;

	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Category.class, fetch = FetchType.LAZY)
	private Category category;
}
