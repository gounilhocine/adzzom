package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Car", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Car extends BaseEntity {

	private static final long serialVersionUID = -5707670649166541140L;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Mark mark;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Model model;

	@Column(unique = false, nullable = false, length = 10)
	private String year;

	@Column(unique = false, nullable = false, precision = 10, scale = 2)
	private String mileage;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.Condition carCondition;

}
