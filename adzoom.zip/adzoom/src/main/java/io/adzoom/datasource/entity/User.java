package io.adzoom.datasource.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "User", uniqueConstraints = @UniqueConstraint(columnNames = {"id"}))
public class User extends BaseEntity {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 137920236030223616L;

	@Column(unique = false, nullable = false, length = 50)
	private String firstName;

	@Column(unique = false, nullable = false, length = 50)
	private String lastName;

	@Column(unique = true, nullable = false, length = 50)
	private String email;

	@Column(unique = false, nullable = true, length = 50)
	private String phone;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Photo photo;

	@Column(unique = false, nullable = false, length = 250)
	private String password;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.AccountStatus accountStatus;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@Column(nullable = true)
	private Set<Ad> ads;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Location location;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Language language;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean newsLetter;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean newsSellingBuying;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean commentsAdsEnabled;

	@Column(unique = false, nullable = true, length = 10)
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Visitor> visitors;

	@Column(unique = false, nullable = true, length = 10)
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Favourite> favourites;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Company company;

	@Column(unique = false, nullable = true, length = 10)
	@OneToMany(mappedBy = "receiver", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Message> inbox;

	@Column(unique = false, nullable = true, length = 10)
	@OneToMany(mappedBy = "sender", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Message> sent = new HashSet<Message>();

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "USERS_ROLES", joinColumns = @JoinColumn(name = "USER_ID", referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "ROLE_ID", referencedColumnName = "id"))
	private Set<Role> roles;
}
