package io.adzoom.datasource.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Photo", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Photo extends BaseEntity {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -2987632069557000561L;

	@Column(unique = false, nullable = false, length = 50)
	private String name;

	@Column(unique = false, nullable = false, length = 5)
	private String extenssion;

	@Column(unique = false, nullable = false, length = 10)
	private String size;

	@Column(unique = false, nullable = false, length = 25)
	@JoinColumn(name = "id")
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.PhotoType photoType;

}
