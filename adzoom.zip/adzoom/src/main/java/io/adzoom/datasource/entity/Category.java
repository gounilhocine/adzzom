package io.adzoom.datasource.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Category", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Category extends BaseEntity {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 2029491044953824695L;

	@JoinColumn(name = "name")
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Enumeration.class, fetch = FetchType.LAZY)
	private Enumeration name;

	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<SubCategory> subCategories = new HashSet<SubCategory>();

}
