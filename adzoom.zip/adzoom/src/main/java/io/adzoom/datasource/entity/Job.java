package io.adzoom.datasource.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Job", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Job extends BaseEntity {

	private static final long serialVersionUID = -783638035566488192L;

	@Column(columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startDate;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Company company;

	@Column(unique = false, nullable = true, precision = 10, scale = 2)
	private BigDecimal salary;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Industry industry;
	
	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.JobType jobType;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Location jobLocation;

}
