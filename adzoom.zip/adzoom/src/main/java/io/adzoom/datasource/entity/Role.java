package io.adzoom.datasource.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Role", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Role extends BaseEntity {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -2173441261105116422L;

	@Column(unique = false, nullable = false, length = 200)
	private String name;

	public Role() {
	}

	public Role(String name) {
		this.name = name;
	}

}
