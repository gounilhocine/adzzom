package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Translation", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Translation extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -2735457000777667809L;

	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Enumeration.class, fetch = FetchType.LAZY)
	private Enumeration enumeration;

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Language.class, fetch = FetchType.LAZY)
	private Language language;

	@Column(unique = false, nullable = false, length = 2000)
	private String label;

}
