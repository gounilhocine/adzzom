package io.adzoom.datasource.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Country", uniqueConstraints = @UniqueConstraint(columnNames = { "iso" }))
public class Country extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -7455848296566929344L;

	@Column(unique = true, nullable = false, length = 3)
	private String iso;

	@Column(unique = true, nullable = false, length = 5)
	private String indicatif;

	@JoinColumn(name = "id")
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Enumeration.class, fetch = FetchType.LAZY)
	private Enumeration name;

	@OneToMany(mappedBy = "country", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<City> cities = new HashSet<City>();

}
