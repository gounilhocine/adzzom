package io.adzoom.datasource.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.Enumeration;

@Repository
public interface EnumerationRepository extends CrudRepository<Enumeration, Long> {

	@Query("select e from Enumeration e where e.code=:code")
	Enumeration findByCode(@Param("code") String code);

	@Query("select e from Enumeration e where e.id=:id")
	Enumeration findEnumerationById(@Param("id") Long id);
}
