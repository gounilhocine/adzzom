package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Industry", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Industry extends BaseEntity {

	private static final long serialVersionUID = 7154935711279371882L;

	@JoinColumn(name = "name")
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Enumeration.class, fetch = FetchType.LAZY)
	private Enumeration name;
}
