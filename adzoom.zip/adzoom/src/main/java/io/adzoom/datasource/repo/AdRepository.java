package io.adzoom.datasource.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.Ad;

@Repository
public interface AdRepository extends CrudRepository<Ad, Long> {

	@Transactional
	@Modifying
	@Query("delete from Ad a where a.id=:id")
	int deleteAdById(@Param("id") Long id);

	@Query("select a from Ad a where a.id=:id")
	Ad findAdById(@Param("id") Long id);

}
