package io.adzoom.datasource.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Property", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Property extends BaseEntity {

	private static final long serialVersionUID = 1144215075785448516L;

	@Column(unique = false, nullable = true, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.BuildingType buildingType;

	@Column(unique = false, nullable = true, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.Condition propertyondition;

	@Column(unique = false, nullable = true, length = 25)
	private String reference;

	@Column(unique = false, nullable = true, length = 200)
	private String note;

	@Column(columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date availableDate;

	@Column(unique = false, nullable = true, precision = 10, scale = 2)
	private BigDecimal size;

	@Column(unique = false, nullable = true, length = 5)
	private String rooms;

	@Column(unique = false, nullable = true, length = 3)
	private Integer beds;

	@Column(unique = false, nullable = true, length = 3)
	private Integer floor;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean furnished;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean parking;

	@Column(unique = false, nullable = true, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.ParkingType parkingType;
}
