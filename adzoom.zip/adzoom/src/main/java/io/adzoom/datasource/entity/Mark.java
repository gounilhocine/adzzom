package io.adzoom.datasource.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Mark", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Mark extends BaseEntity {

	private static final long serialVersionUID = -3807659796380942610L;

	@Column(unique = false, nullable = false, length = 200)
	private String mark;

	@OneToMany(mappedBy = "mark", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Model> models = new HashSet<Model>();

}
