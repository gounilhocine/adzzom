package io.adzoom.datasource.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.Category;

@Repository
public interface CategoryRepository extends CrudRepository<Category, Long> {

	@Query("select c from Category c where c.id=:id")
	Category findCategoryById(@Param("id") Long id);

}