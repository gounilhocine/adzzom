package io.adzoom.datasource.entity;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Ad", uniqueConstraints = @UniqueConstraint(columnNames = {"id"}))
public class Ad extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 7357565138636519927L;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Language language;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Property property;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Car car;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Job job;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = false, fetch = FetchType.LAZY)
	private Category category;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = false, fetch = FetchType.LAZY)
	private SubCategory subCategory;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.AdType adType;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.AdStatus adStatus;

	@Column(unique = false, nullable = false, length = 50)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.PublishType publishType;

	@Column(unique = false, nullable = false, length = 50)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.PaymentType paymentType;

	@Column(unique = false, nullable = false, length = 100)
	private String title;

	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
	private Boolean negociablePrice;

	@Column(unique = false, nullable = false, length = 1, columnDefinition = "boolean default false")
	private Boolean hidePhone;

	@Column(unique = false, nullable = false, length = 4000)
	private String description;

	@Column(unique = false, nullable = true, precision = 10, scale = 2)
	private BigDecimal price;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Photo> photos = new HashSet<Photo>();

	@OneToOne(mappedBy = "ad", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Location location;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user = new User();

	@OneToMany(mappedBy = "ad", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Visitor> visitors = new HashSet<Visitor>();
}
