package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Language", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Language extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 7004216679620920393L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Enumeration name;
	
	@Column(unique = false, nullable = false, length = 5)
	private String code;

}
