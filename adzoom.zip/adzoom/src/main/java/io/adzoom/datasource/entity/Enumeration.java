package io.adzoom.datasource.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Enumeration", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Enumeration extends BaseEntity {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2666386736883944049L;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private Set<Translation> translations = new HashSet<Translation>();

	@Column(unique = false, nullable = false, length = 50)
	private String code;
	
	public Enumeration(String language) {
		this.code = language;
	}
	
	public Enumeration() {
	}

}
