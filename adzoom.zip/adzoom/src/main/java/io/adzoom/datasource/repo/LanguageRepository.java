package io.adzoom.datasource.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.Language;

@Repository
public interface LanguageRepository extends CrudRepository<Language, Long> {

	@Query("select l from Language l where l.code=:code")
	Language findLanguageByCode(@Param("code") String code);

	@Query("select l from Language l where l.id=:id")
	Language findLanguageById(@Param("id") Long id);
}
