package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Visitor", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Visitor extends BaseEntity {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -8280002247954664917L;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Ad ad;

}
