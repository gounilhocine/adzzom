package io.adzoom.datasource.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Payment", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Payment extends BaseEntity {
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -4227054613972971835L;

	@Column(unique = false, nullable = false, length = 250)
	private String description;

	@Column(unique = false, nullable = true, precision = 10, scale = 2)
	private BigDecimal value;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.PaymentType paymentType;

	@Column(unique = false, nullable = false, length = 25)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.PaymentStatus paymentStatus;

}
