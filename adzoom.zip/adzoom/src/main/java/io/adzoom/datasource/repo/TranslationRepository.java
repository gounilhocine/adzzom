package io.adzoom.datasource.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.Translation;

@Repository
public interface TranslationRepository extends CrudRepository<Translation, Long> {

}
