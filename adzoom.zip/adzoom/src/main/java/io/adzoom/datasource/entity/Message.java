package io.adzoom.datasource.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import io.adzoom.util.TwiAdsEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "Message", uniqueConstraints = @UniqueConstraint(columnNames = { "id" }))
public class Message extends BaseEntity{

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 4833726739844073674L;

	@Column(unique = false, nullable = false, length = 4000)
	private String content;
	
	@Column(unique = false, nullable = false, length = 50)
	@Enumerated(EnumType.STRING)
	private TwiAdsEnum.MessageStatus messageStatus;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User sender = new User();

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User receiver = new User();
	
	@Column(unique = false, nullable = false, length = 1, columnDefinition = "boolean default false")
	private Boolean read;


}
