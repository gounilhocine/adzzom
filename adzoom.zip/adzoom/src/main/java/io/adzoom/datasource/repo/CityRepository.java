package io.adzoom.datasource.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.City;
import io.adzoom.datasource.entity.Country;

@Repository
public interface CityRepository extends CrudRepository<Country, Long> {

	@Query("select c from City c where c.id=:id")
	City findCityById(String cityId);

}
