package io.adzoom.datasource.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.adzoom.datasource.entity.SubCategory;

@Repository
public interface  SubCategoryRepository extends CrudRepository<SubCategory, Long> {

	@Query("select sc from SubCategory sc where sc.id=:id")
	SubCategory findSubCategoryById(@Param("id") Long id);
}
