package io.adzoom.model;

import java.util.List;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserModel {

	@NotBlank
	private String firstName;

	@NotBlank
	private String lastName;

	@NotBlank
	private String password;

	@NotBlank
	private String phone;

	@NotBlank
	private String accountType;

	@NotBlank
	private String gender;

	@NotBlank
	private String email;

	private Boolean terms;
	

	private Boolean hidePhoneNumber;
	
	private String address;
	
	private String country;
	
	private Long countryId;
	
	private String city;
	
	private Long cityId;
	
	private String postCode;
	
	private List<CodeLabel> countries;
	
	private List<CodeLabel> cities;
	
	private Boolean newsletter;
	
	private Boolean newsSellingBuying;

}