package io.adzoom.model;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MyAdsModel implements Serializable {

	private static final long serialVersionUID = -8946323300613549461L;

	private List<AdModel> adModels;

	private List<AdModel> favouriteAdModels;

	private List<AdModel> draftAdModels;

	private List<AdModel> archivedAdModels;

	private List<AdModel> pendingAdModels;
	
	private int adsCount;

	private int favouriteAdCount;

	private int savedAdCount;

	private int archivedAdCount;

	private int pendingAdCount;

}
