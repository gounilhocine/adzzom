package io.adzoom.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AdModel implements Serializable {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 8531297087796073694L;

	private String category;
	private String subCategory;
	private List<CodeLabel> categories;
	private List<CodeLabel> subCategories;
	private String adType;
	private String adTitle;
	private String adDescription;
	private BigDecimal adprice;
	private Boolean negotiable;
	private List<String> photos;
	private String sellerName;
	private String sellerEmail;
	private String sellerPhone;
	private Boolean hidePhone;
	private String country;
	private String city;
	private List<CodeLabel> countries;
	private List<CodeLabel> cities;
	private String paymentMethod;
	private List<String> paymentMethods;
	private String publishType;
}
