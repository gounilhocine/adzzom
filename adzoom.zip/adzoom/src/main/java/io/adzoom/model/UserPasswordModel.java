package io.adzoom.model;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserPasswordModel implements Serializable {

	private static final long serialVersionUID = 6530453254240871214L;

	@NotBlank
	private String newPassword;

	@NotBlank
	@Min(8)
	// @Pattern(regexp = "")
	private String confirmNewPassword;

}
