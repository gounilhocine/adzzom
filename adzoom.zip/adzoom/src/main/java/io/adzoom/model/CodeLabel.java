package io.adzoom.model;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CodeLabel implements Serializable {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -4873280985283156064L;

	private String code;
	private String label;
}
