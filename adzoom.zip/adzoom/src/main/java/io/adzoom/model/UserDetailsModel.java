package io.adzoom.model;

import java.util.List;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserDetailsModel {

	@NotBlank
	private String firstName;

	@NotBlank
	private String lastName;

	@NotBlank
	private String phone;

	private String name;
	
	private String address;

	private List<CodeLabel> countries;

	private List<CodeLabel> cities;

	private Long countryId;

	private Long cityId;

	@NotBlank
	private String city;

	@NotBlank
	private String country;

	private String postCode;

	private String photoSrc;

	@NotBlank
	private String email;

	private Boolean hidePhoneNumber;

	private Boolean newsLetter;

	private Boolean commentsAdsEnabled;

	private Boolean newsSellingBuying;

}
