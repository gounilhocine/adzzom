/**
 * 
 */
package io.adzoom.config;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import io.adzoom.service.UserService;

/**
 * Spring Security Config.
 * 
 * @author gouni
 *
 */
@Configuration
@EnableWebSecurity
public class TwiadsSecurityConfig extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {

	private final String[] swaggerUrls = { "/v2/api-docs", "/configuration/ui", "/swagger-resources",
			"/configuration/security", "/swagger.html", "/webjars/**" };

	@Value("${static.src}")
	private String staticSrc;

	@Autowired
	private LoggingAccessDeniedHandler accessDeniedHandler;

	@Autowired
	@Qualifier("userService")
	private UserService userService;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(localeChangeInterceptor());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/static/**").addResourceLocations("file:" + staticSrc + "/");
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
		auth.setUserDetailsService(userService);
		auth.setPasswordEncoder(passwordEncoder());
		return auth;
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests().antMatchers("/resources/**").permitAll()
		
		        .antMatchers("/resources/static/**")
				.permitAll().antMatchers("/resources/templates/**").permitAll()
				.antMatchers("/", "/js/**", "/css/**", "/img/**", "/webjars/**").permitAll()
				.antMatchers("/login**")
				.permitAll().antMatchers(swaggerUrls)
				.fullyAuthenticated().antMatchers("/dashboard/**").hasAnyRole("USER")
	            .antMatchers("/admin/**").hasAnyRole("ADMIN")
				.and().formLogin().loginPage("/login").permitAll().defaultSuccessUrl("/dashboard/account-home")
				.failureUrl("/login?error").permitAll()
				.and().csrf()
				.disable()
				.logout()
				.invalidateHttpSession(true)
				.clearAuthentication(true).logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
				.logoutSuccessUrl("/login?logout")
				.deleteCookies("JSESSIONID").permitAll().permitAll()
				.and()
				.exceptionHandling().accessDeniedHandler(accessDeniedHandler)
				.and().sessionManagement()
				.maximumSessions(1).expiredUrl("/login?logout");
	}

	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
		lci.setParamName("lang");
		return lci;
	}
	
	

	@Bean
	public SessionLocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.US);
		return slr;
	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
