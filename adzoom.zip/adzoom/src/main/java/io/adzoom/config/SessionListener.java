package io.adzoom.config;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * To configure Session timeout.
 * 
 * @author gouni
 *
 */
@Configuration
public class SessionListener implements HttpSessionListener {

	private final Logger logger = LoggerFactory.getLogger(SessionListener.class);

	@Value("${session.timeout}")
	private int sessionTimeout;

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	public void sessionCreated(HttpSessionEvent event) {
		event.getSession().setMaxInactiveInterval(sessionTimeout);
		logger.debug("==== Session is created ====");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @{see_to_overriden}
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		event.getSession().invalidate();
		logger.debug("==== Session is destroyed ====");
	}
}
