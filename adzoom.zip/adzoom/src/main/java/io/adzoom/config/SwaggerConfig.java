package io.adzoom.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;

import springfox.documentation.builders.AuthorizationCodeGrantBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.GrantType;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.service.Tag;
import springfox.documentation.service.TokenEndpoint;
import springfox.documentation.service.TokenRequestEndpoint;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger Config.
 * 
 * @author gouni lhocine
 * @version 1.0
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Value("${swagger.auth.server}")
	private String authServer;

	@Value("${swagger.clientid}")
	private String clientid;

	@Value("${swagger.clientsecret}")
	private String clientSecret;

	/**
	 * Api swagger.
	 * 
	 * @return
	 */
	@Bean
	public Docket api() {
		return new Docket(
				DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.basePackage("io.adzoom.controller")).paths(PathSelectors.any()).build().apiInfo(getApiInformation()).tags(new Tag(
						"Twiads User", "Controller for Twiads User"), new Tag("Twiads Ad", "Controller for Twiads Ad"), new Tag("Adzoom Admin",
								"Controller for Twiads Admin")).useDefaultResponseMessages(false).securitySchemes(Arrays.asList(securityScheme())).securityContexts(Arrays.asList(securityContext())).globalResponseMessage(RequestMethod.GET, getCustomizedResponseMessages());
	}

	/**
	 * Api Information.
	 * 
	 * @return
	 */
	private ApiInfo getApiInformation() {
		return new ApiInfo("Twiads REST API", "This is a Twiads API", "1.0", "API Terms of Service URL", new Contact("Oasis IT Team", "www.twiads.com", "contact@twiads.com"), "API License",
				"API License URL", Collections.emptyList());
	}

	/**
	 * Get Customized Response Messages.
	 * 
	 * @return
	 */
	private List<ResponseMessage> getCustomizedResponseMessages() {
		List<ResponseMessage> responseMessages = new ArrayList<>();
		responseMessages.add(new ResponseMessageBuilder().code(500).message("Server has crashed!!").responseModel(new ModelRef("string")).build());
		responseMessages.add(new ResponseMessageBuilder().code(403).message("You shall not pass!!").build());
		return responseMessages;
	}

	/**
	 * Access scopes to Web Services.
	 * 
	 * @return
	 */
	private AuthorizationScope[] scopes() {
		AuthorizationScope[] scopes =
				{new AuthorizationScope("chargement", "for read operations"), new AuthorizationScope("creation", "for write operations"), new AuthorizationScope("get", "Access Get API")};
		return scopes;
	}

	/**
	 * Security Swagger Configuration.
	 * 
	 * @return
	 */
	@Bean
	public SecurityConfiguration security() {
		return SecurityConfigurationBuilder.builder().clientId(clientid).clientSecret(clientSecret).scopeSeparator(" ").useBasicAuthenticationWithAccessCodeGrant(true).build();
	}

	/**
	 * Security Context.
	 * 
	 * @return
	 */
	private SecurityContext securityContext() {
		return SecurityContext.builder().securityReferences(Arrays.asList(new SecurityReference("spring_oauth", scopes()))).forPaths(PathSelectors.regex("/.*")).build();
	}

	/**
	 * Swagger Security Scheme.
	 * 
	 * @return
	 */
	private SecurityScheme securityScheme() {
		GrantType grantType =
				new AuthorizationCodeGrantBuilder().tokenEndpoint(new TokenEndpoint(authServer + "/token", "oauthtoken")).tokenRequestEndpoint(new TokenRequestEndpoint(authServer + "/swagger.html",
						clientid, clientSecret)).build();

		SecurityScheme oauth = new OAuthBuilder().name("spring_oauth").grantTypes(Arrays.asList(grantType)).scopes(Arrays.asList(scopes())).build();
		return oauth;
	}

}
