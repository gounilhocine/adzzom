package io.adzoom.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import io.adzoom.datasource.entity.Ad;
import io.adzoom.datasource.entity.City;
import io.adzoom.datasource.entity.Country;
import io.adzoom.datasource.entity.Favourite;
import io.adzoom.datasource.entity.Message;
import io.adzoom.datasource.entity.User;
import io.adzoom.model.AdModel;
import io.adzoom.model.CodeLabel;
import io.adzoom.model.MyAdsModel;
import io.adzoom.model.UserDetailsModel;
import io.adzoom.model.UserModel;
import io.adzoom.service.MasterDataService;
import io.adzoom.service.UserService;
import io.adzoom.util.Refs;
import io.adzoom.util.SessionUtils;
import io.adzoom.util.TwiAdsEnum.AdStatus;
import io.adzoom.util.TwiadsConstant;

@Controller
public class GetPageController extends AbstractController {

	@Autowired
	private UserService userService;

	@Autowired
	private MasterDataService masterDataService;

	@RequestMapping(value = {"", "/", "/home"}, method = RequestMethod.GET)
	public String homePage() { return "home"; }

	@GetMapping("/language")
	public String internationalPage() { return "language"; }

	@GetMapping("/postads")
	public String postads() { return "dashboard/post-ads"; }

	@GetMapping("/category")
	public String category() { return "category"; }

	@GetMapping("/faq")
	public String faq() { return "faq"; }

	@GetMapping("/about")
	public String about() { return "about"; }

	@GetMapping("/blogs")
	public String blogs() { return "blogs"; }

	@GetMapping("/ads-details")
	public String adsDetails() { return "ads-details"; }

	@GetMapping("/login-validation")
	public String loginValidation() { return "login-validation"; }

	@GetMapping("/dashboard/account-home")
	public ModelAndView accountHome(ModelAndView modelAndView, HttpServletRequest req) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		UserDetailsModel model = new UserDetailsModel();
		User user = userService.findByEmail(userDetails.getUsername());
		MyAdsModel myAdsModel = getmyAdsModel(user, req);
		getUserDetailsModel(user, model, req);
		// Details
		modelAndView.addObject("user", model);
		// My ads
		modelAndView.addObject("myAdsModel", myAdsModel);

		// New Messages
		modelAndView.addObject("messagesCount", getMessagesCount(user));

		modelAndView.setViewName("dashboard/account-home");
		return modelAndView;
	}

	/**
	 * @param user
	 * @param model
	 */
	private void getUserDetailsModel(User user, UserDetailsModel model, HttpServletRequest req) {

		if (user != null) {
			// Set Name
			model.setFirstName(user.getFirstName());
			model.setLastName(user.getLastName());
			model.setName(model.getFirstName() + " " + model.getLastName());

			// Set Location
			if (user.getLocation() != null) {
				model.setAddress(user.getLocation().getAddress());
				model.setPostCode(user.getLocation().getPostCode());
				CodeLabel countryCodeLabel = null;
				Country country = null;
				if (user.getLocation().getCountry() != null) {
					countryCodeLabel = masterDataService.getCountryCodeLabelByLanguage(user.getLocation().getCountry().getId(), SessionUtils.getLanguage(req));
					country = user.getLocation().getCountry();
				}
				model.setCountry(countryCodeLabel.getCode());
				CodeLabel cityCodeLabel = new CodeLabel();
				if (user.getLocation().getCity() != null) {
					cityCodeLabel.setCode(String.valueOf(user.getLocation().getCity().getId()));
					cityCodeLabel.setLabel(String.valueOf(user.getLocation().getCity().getName()));
				}
				model.setCity(cityCodeLabel.getCode());

				// Set List of cities by country
				if (country != null) {
					model.setCities(getCodeLabelCities(country.getCities()));
				}
			}
			// Set List of countries
			model.setCountries(masterDataService.getCountryCodeLabelListByIdAndLanguage(SessionUtils.getLanguage(req)));

			// set Email
			model.setEmail(user.getEmail());

			// Set phone
			model.setPhone(user.getPhone());

			// set Photo
			if (user.getPhoto() != null) {
				model.setPhotoSrc(user.getPhoto().getName());
			} else {
				model.setPhotoSrc(TwiadsConstant.photo_profile);
			}

			// Set newsletter
			model.setNewsLetter(user.getNewsLetter());
			model.setNewsSellingBuying(user.getNewsSellingBuying());

			// Comment Enabled
			model.setCommentsAdsEnabled(user.getCommentsAdsEnabled());
		}
	}

	/**
	 * @param cities
	 * @return
	 */
	private List<CodeLabel> getCodeLabelCities(Set<City> cities) {
		List<CodeLabel> codeLabels = new ArrayList<CodeLabel>();
		if (cities != null) {
			cities.stream().forEach(item -> {
				CodeLabel codeLabel = new CodeLabel();
				codeLabel.setCode(String.valueOf(item.getId()));
				codeLabel.setLabel(item.getName());
				codeLabels.add(codeLabel);
			});
		}
		return codeLabels;
	}

	@GetMapping("/register")
	public ModelAndView showRegistrationForm(ModelAndView modelAndView, UserModel model) { modelAndView.addObject("user", model); modelAndView.setViewName("register"); return modelAndView; }

	@GetMapping("/login")
	public String showLoginForm(Model model) { return "login"; }

	@GetMapping("/terms-conditions")
	public ModelAndView termsConditions() { ModelAndView mav = new ModelAndView("/terms-conditions"); return mav; }

	@GetMapping("/logout")
	public ModelAndView logout() { ModelAndView mav = new ModelAndView("/login"); return mav; }

	@GetMapping("/access-denied")
	public String accessDenied() { return "/access-denied"; }
}