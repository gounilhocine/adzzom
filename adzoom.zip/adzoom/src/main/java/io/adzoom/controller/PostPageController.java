package io.adzoom.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import io.adzoom.datasource.entity.Location;
import io.adzoom.datasource.entity.User;
import io.adzoom.model.UserDetailsModel;
import io.adzoom.model.UserLoginModel;
import io.adzoom.model.UserModel;
import io.adzoom.model.UserPasswordModel;
import io.adzoom.model.UserPreferencesModel;
import io.adzoom.service.UserService;
import io.adzoom.util.Refs;

@Controller
public class PostPageController {

	@Autowired
	private UserService userService;
	
	private final Logger logger = LoggerFactory.getLogger(PostPageController.class);

	@PostMapping("/login")
	public String login(@ModelAttribute("user") @Valid UserLoginModel model, BindingResult result, HttpServletRequest req) {
		User existing = userService.findByEmail(model.getUserName());
		if (existing != null) {
			result.rejectValue("userName", null, "There is already an account registered with that email");
		}

		if (result.hasErrors()) {
			return "login";
		}
		return "user/daschboard-user";
	}

	/**
	 * @param modelAndView
	 * @param model
	 * @param bindingResult
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView processRegistrationForm(ModelAndView modelAndView, @Valid UserModel model, BindingResult bindingResult, HttpServletRequest request) {
		// Lookup user in database by e-mail
		User userExists = userService.findByEmail(model.getEmail());
		if (userExists != null) {
			modelAndView.addObject("alreadyRegisteredMessage", "Oops!  There is already a user registered with" + " the email provided.");
			modelAndView.setViewName("register");
			bindingResult.reject("email");
		}

		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("register");
		} else { // new user so we create user and send confirmation e-mail
			userService.save(model, request);
			modelAndView.addObject("confirmationMessage", "A confirmation e-mail has been sent to " + model.getEmail());
			modelAndView.setViewName("register");
		}
		return modelAndView;
	}

	/**
	 * @param modelAndView
	 * @param model
	 * @param bindingResult
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/update-profile", method = RequestMethod.POST)
	public ModelAndView updateProfile(ModelAndView modelAndView, @Valid UserDetailsModel model, BindingResult bindingResult, HttpServletRequest request) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = null;
		try {
			if (authentication != null && authentication.getName() != null) {
				user = userService.findByEmail(authentication.getName());
			}
			if (user != null) {
				// save
				user.setFirstName(model.getFirstName());
				user.setLastName(model.getLastName());
				user.setEmail(model.getEmail());
				Location location = user.getLocation() == null ? new Location() : user.getLocation();
				location.setCity(Refs.getCityById(model.getCity()));
				location.setCreateDate(new Date());
				location.setCountry(Refs.getCountryById(model.getCountryId()));
				location.setPostCode(model.getPostCode());
				if (user.getLocation() != null && user.getLocation().getCity() != null) {
					location.setCreateDate(new Date());
				}
				location.setUpdateDate(new Date());
				user.setLocation(location);
				user.setPhone(model.getPhone());
				userService.update(user);
				modelAndView.addObject("confirmationMessage", "Your information is updated");
			} else {
				modelAndView.addObject("errorMessage", "user does not exist");
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		modelAndView.setViewName("dashboard/account-home");
		return modelAndView;
	}

	/**
	 * @param modelAndView
	 * @param model
	 * @param bindingResult
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/update-settings", method = RequestMethod.POST)
	public ModelAndView updateDettings(ModelAndView modelAndView, @Valid UserPasswordModel model, BindingResult bindingResult, HttpServletRequest request) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = null;
		try {
			if (authentication != null && authentication.getName() != null) {
				user = userService.findByEmail(authentication.getName());
			}
			if (user != null && model.getNewPassword() != null && model.getConfirmNewPassword() != null && StringUtils.equals(model.getConfirmNewPassword(), model.getNewPassword())) {
				user.setPassword(model.getNewPassword());
				user.setUpdateDate(new Date());
				userService.update(user);
				modelAndView.addObject("confirmationMessage", "Your password is updated");
			} else {
				modelAndView.addObject("errorMessage", "user does not exist");
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		modelAndView.setViewName("dashboard/account-home");
		return modelAndView;
	}

	/**
	 * @param modelAndView
	 * @param model
	 * @param bindingResult
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/update-preferences", method = RequestMethod.POST)
	public ModelAndView updatePreferences(ModelAndView modelAndView, @Valid UserPreferencesModel model, BindingResult bindingResult, HttpServletRequest request) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = null;
		try {
			if (authentication != null && authentication.getName() != null) {
				user = userService.findByEmail(authentication.getName());
			}
			if (user != null) {
				user.setNewsLetter(model.getNewsletter());
				user.setNewsSellingBuying(model.getNewsSellingBuying());
				user.setUpdateDate(new Date());
				userService.update(user);
				modelAndView.addObject("confirmationMessage", "Your password is updated");
			} else {
				modelAndView.addObject("errorMessage", "user does not exist");
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		modelAndView.setViewName("dashboard/account-home");
		return modelAndView;
	}

	@ModelAttribute("user")
	public UserModel userRegistrationModel() { return new UserModel(); }
}
