package io.adzoom.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import io.adzoom.datasource.entity.Ad;
import io.adzoom.datasource.entity.Favourite;
import io.adzoom.datasource.entity.Message;
import io.adzoom.datasource.entity.User;
import io.adzoom.model.AdModel;
import io.adzoom.model.MyAdsModel;
import io.adzoom.util.Refs;
import io.adzoom.util.SessionUtils;
import io.adzoom.util.TwiAdsEnum.AdStatus;

public abstract class AbstractController {

	private MyAdsModel myAdsModel = null;

	private int messagesCount = 0;
	/**
	 * @param user
	 * @return
	 */
	int getMessagesCount(User user) {
		Set<Message> inbox = user.getInbox();
		if (inbox != null) {
			inbox.stream().forEach(item -> {
				if (!item.getRead()) {
					messagesCount++;
				}
			});
		}
		return messagesCount;
	}

	/**
	 * @param user
	 * @param req
	 * @return
	 */
	 MyAdsModel getmyAdsModel(User user, HttpServletRequest req) {
		myAdsModel = new MyAdsModel();
		myAdsModel.setFavouriteAdModels(getFavoriteAds(user.getFavourites(), req));
		myAdsModel.setArchivedAdModels(getAdsByStatus(user.getAds(), req, AdStatus.ARCHIVED));
		myAdsModel.setPendingAdModels(getAdsByStatus(user.getAds(), req, AdStatus.PENDING_APPROVAL));
		myAdsModel.setDraftAdModels(getAdsByStatus(user.getAds(), req, AdStatus.DRAFT));

		myAdsModel.setFavouriteAdCount(getFavoriteAds(user.getFavourites(), req).size());
		myAdsModel.setArchivedAdCount(getAdsByStatus(user.getAds(), req, AdStatus.ARCHIVED).size());
		myAdsModel.setPendingAdCount(getAdsByStatus(user.getAds(), req, AdStatus.PENDING_APPROVAL).size());
		myAdsModel.setSavedAdCount(getAdsByStatus(user.getAds(), req, AdStatus.DRAFT).size());

		return myAdsModel;

	}

	/**
	 * @param ads
	 * @param req
	 * @return
	 */
	private List<AdModel> getAdsByStatus(Set<Ad> ads, HttpServletRequest req, AdStatus adStatus) {
		List<AdModel> list = new ArrayList<AdModel>();
		if (ads != null) {
			ads.stream().forEach(item -> {
				if (item.getAdStatus().equals(adStatus)) {
					AdModel adModel = new AdModel();
					adModel.setAdDescription(item.getDescription());
					adModel.setAdprice(item.getPrice());
					adModel.setAdTitle(item.getTitle());
					adModel.setCategory(Refs.getEnumerationByIdAndByLanguage(item.getCategory().getId(), SessionUtils.getLanguage(req)));
					adModel.setCountry(Refs.getEnumerationByIdAndByLanguage(item.getLocation().getCountry().getName().getId(), SessionUtils.getLanguage(req)));
					adModel.setCity(item.getLocation().getCity().getName());
					adModel.setHidePhone(item.getHidePhone());
					adModel.setNegotiable(item.getNegociablePrice());
					adModel.setSellerName(item.getUser().getFirstName() + " " + item.getUser().getLastName());
					adModel.setSellerEmail(item.getUser().getEmail());
					adModel.setSubCategory(Refs.getEnumerationByIdAndByLanguage(item.getSubCategory().getId(), SessionUtils.getLanguage(req)));
					adModel.setSellerPhone(item.getUser().getPhone());
					adModel.setPublishType(item.getPaymentType().name());
					list.add(adModel);
				}
			});
		}
		return list;

	}

	/**
	 * @param favourites
	 * @param req
	 * @return
	 */
	private List<AdModel> getFavoriteAds(Set<Favourite> favourites, HttpServletRequest req) {
		List<AdModel> list = new ArrayList<AdModel>();
		if (favourites != null) {
			favourites.stream().forEach(item -> {
				AdModel adModel = new AdModel();
				adModel.setAdDescription(item.getAd().getDescription());
				adModel.setAdprice(item.getAd().getPrice());
				adModel.setAdTitle(item.getAd().getTitle());
				adModel.setCategory(Refs.getEnumerationByIdAndByLanguage(item.getAd().getCategory().getId(), SessionUtils.getLanguage(req)));
				adModel.setCountry(Refs.getEnumerationByIdAndByLanguage(item.getAd().getLocation().getCountry().getName().getId(), SessionUtils.getLanguage(req)));
				adModel.setCity(item.getAd().getLocation().getCity().getName());
				adModel.setHidePhone(item.getAd().getHidePhone());
				adModel.setNegotiable(item.getAd().getNegociablePrice());
				adModel.setSellerName(item.getUser().getFirstName() + "" + item.getUser().getLastName());
				adModel.setSellerEmail(item.getUser().getEmail());
				adModel.setSubCategory(Refs.getEnumerationByIdAndByLanguage(item.getAd().getSubCategory().getId(), SessionUtils.getLanguage(req)));
				adModel.setSellerPhone(item.getUser().getPhone());
				adModel.setPublishType(item.getAd().getPaymentType().name());
				list.add(adModel);
			});
		}
		return list;
	}
}
