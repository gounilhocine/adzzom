package io.adzoom.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionUtils {

	public static String getLanguage(HttpServletRequest req) {
		HttpSession session = req.getSession();
		if (session.getAttribute("language") != null) {
			return session.getAttribute("language").toString();
		}
		return "en";
	}

	public static void setLanguage(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.setAttribute("language", req.getLocale().getLanguage());
	}
}
