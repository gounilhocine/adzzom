package io.adzoom.util;

public class TwiAdsEnum {

	public enum JobType {
		FULL_TIME, PART_TIME;
	}

	public enum AccountStatus {
		ENABLED, BLOCKED, TO_VALIDATE, CLOSED;
	}

	public enum AccountType {
		PERSONNAL, PROFESSIONAL;
	}

	public enum AdStatus {
		PUBLISHED, UNPUBLISHED, BLOCKED, PENDING_APPROVAL, ARCHIVED, DRAFT;
	}

	public enum AdType {
		PRIVATE, BUSINESS;
	}

	public enum BuildingType {
		APARTMENT, HOUSE, GROUND, PARKING, OTHER;
	}

	public enum Condition {
		NEW, OLD;
	}

	public enum MessageStatus {
		DRAFT, STARRED, IMPORTANT, ARCHIVED, NEW;
	}

	public enum ParkingType {
		COVERED, PUBLIC, INDIVIDUAL;
	}

	public enum PaymentStatus {
		APPROVED, REFUSED, FINALISED;
	}

	public enum PaymentType {
		CB, PAYPAL;
	}

	public enum PhotoType {
		PROFILE, AD;
	}

	public enum PublishType {
		REGULAR, URGENT, TOP, URGENT_AND_TOP, VIDEO;
	}

	public enum Role {
		ROLE_USER, ROLE_ADMIN;
	}
}
