package io.adzoom.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.adzoom.datasource.entity.Category;
import io.adzoom.datasource.entity.City;
import io.adzoom.datasource.entity.Country;
import io.adzoom.datasource.entity.Language;
import io.adzoom.datasource.entity.Translation;
import io.adzoom.model.CodeLabel;
import io.adzoom.service.MasterDataService;

@Component
public class Refs {

	@Autowired
	private static MasterDataService masterDataService = new MasterDataService();

	public static Category getCategoryById(Long id) { return masterDataService.getCategoryById(id); }

	public static CodeLabel getCategoryCodeLabelByLanguage(Long id, String language) { return masterDataService.getCategoryCodeLabelByLanguage(id, language); }

	public static List<CodeLabel> getCategoryCodeLabelListByIdAndLanguage(String language) { return masterDataService.getCategoryCodeLabelListByIdAndLanguage(language); }

	public static String getCategoryNameByIdAndByLanguage(Long id, String language) { return masterDataService.getCategoryNameByIdAndByLanguage(id, language); }

	public static CodeLabel getCountryCodeLabelByLanguage(Long id, String language) { return masterDataService.getCountryCodeLabelByLanguage(id, language); }

	public static List<CodeLabel> getCountryCodeLabelListByIdAndLanguage(String language) { return masterDataService.getCountryCodeLabelListByIdAndLanguage(language); }

	public static String getCountryNameByIdAndByLanguage(Long id, String language) { return masterDataService.getCountryNameByIdAndByLanguage(id, language); }

	public static Language getLanguageByCode(String languageCode) { return masterDataService.getLanguageByCode(languageCode); }

	public static CodeLabel getLanguageCodeLabelByLanguage(Long id, String language) { return masterDataService.getLanguageCodeLabelByLanguage(id, language); }

	public static List<CodeLabel> getLanguageCodeLabelListByIdAndLanguage(String language) { return masterDataService.getLanguageCodeLabelListByIdAndLanguage(language); }

	public static String getLanguageNameByIdAndByLanguage(Long id, String language) { return masterDataService.getLanguageNameByIdAndByLanguage(id, language); }

	public static CodeLabel getSubCategoryCodeLabelByLanguage(Long id, String language) { return masterDataService.getSubCategoryCodeLabelByLanguage(id, language); }

	public static List<CodeLabel> getSubCategoryCodeLabelListByIdAndLanguage(String language) { return masterDataService.getSubCategoryCodeLabelListByIdAndLanguage(language); }

	public static String getSubCategoryNameByIdAndByLanguage(Long id, String language) { return masterDataService.getSubCategoryNameByIdAndByLanguage(id, language); }

	public static Country getCountryById(Long countryId) { return masterDataService.getCountryById(countryId); }

	public static City getCityById(String cityId) { return masterDataService.getCityById(cityId); }

	public static String getEnumerationByIdAndByLanguage(Long id, String language) { return masterDataService.getEnumerationByIdAndByLanguage(id, language); }

}
