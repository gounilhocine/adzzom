package io.adzoom.util;

public class TwiadsConstant {

	public static String photo_profile = "static/images/user.jpg";

}
